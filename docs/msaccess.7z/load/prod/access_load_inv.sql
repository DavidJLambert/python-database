.mode csv
.import inv.csv INVENTORY
.exit
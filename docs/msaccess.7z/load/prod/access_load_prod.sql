.mode csv
.import prod.csv PRODUCTS
.exit
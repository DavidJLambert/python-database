.mode csv
.import us_cust.csv  CUSTOMERS
.import row_cust.csv CUSTOMERS
.exit
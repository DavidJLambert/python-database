.mode csv
.import jan_orderlines.csv ORDERLINES
.import feb_orderlines.csv ORDERLINES
.import mar_orderlines.csv ORDERLINES
.import apr_orderlines.csv ORDERLINES
.import may_orderlines.csv ORDERLINES
.import jun_orderlines.csv ORDERLINES
.import jul_orderlines.csv ORDERLINES
.import aug_orderlines.csv ORDERLINES
.import sep_orderlines.csv ORDERLINES
.import oct_orderlines.csv ORDERLINES
.import nov_orderlines.csv ORDERLINES
.import dec_orderlines.csv ORDERLINES
.exit
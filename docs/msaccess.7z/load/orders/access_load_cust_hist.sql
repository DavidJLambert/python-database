.mode csv
.import jan_cust_hist.csv CUST_HIST
.import feb_cust_hist.csv CUST_HIST
.import mar_cust_hist.csv CUST_HIST
.import apr_cust_hist.csv CUST_HIST
.import may_cust_hist.csv CUST_HIST
.import jun_cust_hist.csv CUST_HIST
.import jul_cust_hist.csv CUST_HIST
.import aug_cust_hist.csv CUST_HIST
.import sep_cust_hist.csv CUST_HIST
.import oct_cust_hist.csv CUST_HIST
.import nov_cust_hist.csv CUST_HIST
.import dec_cust_hist.csv CUST_HIST
.exit
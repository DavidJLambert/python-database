.mode csv
.import jan_orders.csv ORDERS
.import feb_orders.csv ORDERS
.import mar_orders.csv ORDERS
.import apr_orders.csv ORDERS
.import may_orders.csv ORDERS
.import jun_orders.csv ORDERS
.import jul_orders.csv ORDERS
.import aug_orders.csv ORDERS
.import sep_orders.csv ORDERS
.import oct_orders.csv ORDERS
.import nov_orders.csv ORDERS
.import dec_orders.csv ORDERS
.exit